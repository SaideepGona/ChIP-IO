PLEASE READ THROUGH THIS DOCUMENT BEFORE USING THE PROVIDED data

-Thank you for using ChIP-IO-

Current Reference Genome: GRCh38
Current Annotation: gencode.v29

------------ Output Description ------------

*** .tgtable file ***

Your output folder contains a .tgtable file. This is actually a tab-seperated value(tsv) file. It contains tabular data 
with the metadata:

Rows: Gene + Gene Regions
Columns: Transcription Factors

Table entries correspond to the number of ChIP-Seq peaks for a given transcription factor mapping to regulatory regions of
a given gene. Currently these peaks come only from raw ChIP-Seq peak data, but future versions will include motif/epigenetic
prior binding site prediction to reduce false positive rates where applicable.

*** .bintgtable file ***

Same as above, except entries are binarized as 0 or 1 based on the "peak count" threshold.

*** .pkl file ***

Python readable binarytable object. Holds the same information as the above .tsv files but can be read into python as a nested
dictionary object. Once read in, entries can be pulled as table[gene][tf]

------------ Important Notes! ------------

- In general, "0" table entries are not intended to provide confidence for lack of TF-gene association. ChIP-Seq studies still 
cover only a subset of transcription factors, and there may always be variation across cell states which is not well
captured. Instead, focus on interpreting non-zero entries as providing experimental confidence of association over neutral.

- If multi-tissue selection was done, the final output table will contain a union of data across tissue types specified in the
ChIP-IO query. If you are interested in tf-gene association for a single tissue type, submit a new query inputting only that 
tissue. 

------------ Current Submission ------------

time stamp: 2018-12-18_00:06:47.752669

promoter: True

enhancer: True

transcription_factors: ETV4,NEUROD4,SOX6,ZBTB8A,TBP,ZNF629,TFAP2C,TCF7,SP4,ZNF394,ZNF558,NFXL1,ZNF300,CEBPZ,PBX1,ZNF280C,BRF2,E2F2,JUN,ZNF157,ZNF548,CEBPG,KAT7,ZNF114,ZNF207,THAP4,MYNN,ZBTB7C,ZNF70,ZNF654,ZFX,SOX9,ZNF398,SREBF2,ZFHX3,NFE2L2,TSHZ2,MEIS3,ZNF45,ZNF658,ZNF610,SCRT1,ZSCAN18,ZNF407,ZNF530,MAX,ZNF43,DRAP1,ZNF384,NRF1,MAZ,RXRB,ZBTB17,ZHX2,ZNF217,OVOL3,SIX4,ZNF8,ZNF747,INSM1,ZBTB40,ZNF488,EBF1,TEAD1,ELF2,ZNF512,ZNF138,ZNF76,HNF4A,ELK4,ZNF670,E2F6,ELF4,EGR4,ZSCAN29,MEF2D,ZNF624,ZNF184,SRF,ZIC2,MBD4,ZBTB48,BCL6,ZNF239,KMT2B,DEAF1,CHAMP1,ZNF544,TEAD2,TFAP4,ZNF48,HINFP,ZSCAN5C,PRDM6,NR2F6,NCOA2,MEF2C,DNMT1,HHEX,SNAI3,NFIL3,KLF6,ZNF404,ZNF580,ZNF181,RARB,ZNF316,ZSCAN26,KLF16,TSC22D1,KLF9,BATF,HLF,ZNF354C,ZNF766,REL,ZNF2,IRF5,ZNF84,ZNF57,ZNF10,ZNF560,ZNF140,TCF7L1,MBD1,E2F7,HSF5,ZNF664,SALL1,KLF17,TFDP2,SP5,ZNF366,ATF4,DPF3,ZNF416,ZGPAT,ZNF266,CEBPD,ZNF776,CTCFL,MLX,ERG,CREM,RUNX2,ZNF777,PRDM10,ZNF197,YBX1,ZNF22,ZBTB20,ZNF707,ZNF680,MYC,ZNF519,ZNF14,PRDM4,USF1,SIX5,ZFP1,MXI1,ZNF248,T,MTF2,IRF9,KDM5B,ESR2,MAFF,TAL1,ZXDB,ZSCAN16,ZFP69,JUND,ZNF547,ZNF644,ZFP37,ZNF318,TGIF1,ZNF34,OSR1,ZBTB49,ZNF600,ZNF174,MITF,CBX2,ZNF66,ZC3H8,KLF5,ZNF148,STAT1,NANOG,ZNF30,RBAK,NR3C1,ZNF24,ZZZ3,ZFP64,IRF7,HMGN3,KLF7,SMAD4,THRB,RFX5,NFE4,NR2C2,ZIK1,IKZF2,SPIC,PPARG,ZNF324,ZBTB5,STAT5A,MYB,HOMEZ,HNF4G,ZNF645,PRDM1,TCF3,SP7,KLF8,ZNF524,TCF21,TFEB,ZFP3,RFX7,MIXL1,ZNF578,ETV6,GATA6,ZNF740,ZNF350,ZKSCAN5,ZSCAN2,ZBTB10,CREBL2,ZNF274,TBX1,ZNF514,MAFG,ZNF555,ADNP,ZNF639,ZNF18,ZSCAN9,BCL11B,ZNF837,ZNF697,ZNF7,ZNF391,ZNF605,HOXC5,ZBED9,TEAD4,SMAD5,KLF1,HIC1,ESRRB,NR4A1,ZNF155,ZNF169,NFIA,ZNF785,ZNF687,REST,E2F5,ZNF589,ATF7,ZNF79,ZNF280D,BACH1,CTCF,ZNF20,ZNF507,REPIN1,KLF3,ZNF423,MXD1,ZNF335,ZNF69,ZNF850,ETS2,THRA,ZNF195,NFATC4,LCORL,NFYC,BHLHE40,ZNF16,VDR,ZNF579,ZNF704,MAFK,HES5,ZNF529,E2F4,ZNF19,ZNF365,MXD4,ZNF347,ZNF146,CUX1,HMG20B,ZKSCAN8,ZBTB26,ZNF584,NKX2-8,HBP1,NFIC,ZNF26,ZSCAN4,SKIL,ZNF491,ZNF175,SOX1,ELK1,CDC5L,SOX5,KLF4,HMBOX1,ZNF426,IRF4

tissue_types: kidney

pileup: 1.0

log_p: 3.0

fold_enrichment: 1.0

log_q: 3.0

dist_tss_upstream: 1000

dist_tss_downstream: 100

peak_count: 1

include_motif_sites: <input checked id="include_motif_sites" name="include_motif_sites" type="checkbox" value="y">

motif_discovery: <input id="motif_discovery" name="motif_discovery" type="checkbox" value="y">

email: send.results.here@peaks.com