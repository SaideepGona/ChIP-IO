PLEASE READ THROUGH THIS DOCUMENT BEFORE USING THE PROVIDED data

-Thank you for using ChIP-IO-

Current Reference Genome: GRCh38
Current Annotation: gencode.v29

------------ Output Description ------------

*** .tgtable file ***

Your output folder contains a .tgtable file. This is actually a tab-seperated value(tsv) file. It contains tabular data 
with the metadata:

Rows: Gene + Gene Regions
Columns: Transcription Factors

Table entries correspond to the number of ChIP-Seq peaks for a given transcription factor mapping to regulatory regions of
a given gene. Currently these peaks come only from raw ChIP-Seq peak data, but future versions will include motif/epigenetic
prior binding site prediction to reduce false positive rates where applicable.

*** .bintgtable file ***

Same as above, except entries are binarized as 0 or 1 based on the "peak count" threshold.

*** .pkl file ***

Python readable binarytable object. Holds the same information as the above .tsv files but can be read into python as a nested
dictionary object. Once read in, entries can be pulled as table[gene][tf]

------------ Important Notes! ------------

- In general, "0" table entries are not intended to provide confidence for lack of TF-gene association. ChIP-Seq studies still 
cover only a subset of transcription factors, and there may always be variation across cell states which is not well
captured. Instead, focus on interpreting non-zero entries as providing experimental confidence of association over neutral.

- If multi-tissue selection was done, the final output table will contain a union of data across tissue types specified in the
ChIP-IO query. If you are interested in tf-gene association for a single tissue type, submit a new query inputting only that 
tissue. 

------------ Current Submission ------------

time stamp: 2018-12-18_03:18:12.166907

promoter: True

enhancer: True

transcription_factors: ZNF217,HOMEZ,ZNF530,ZNF547,TSHZ2,ZNF184,SALL1,ZNF605,KDM5B,JUN,BACH1,GATA6,MXD1,STAT5A,ZSCAN5C,ZNF658,ZBTB10,ZNF146,NCOA2,BCL11B,NFATC4,HES5,ZNF18,THAP4,TCF3,NKX2-8,ZNF578,ZNF645,CEBPZ,EBF1,ADNP,ZNF580,SMAD5,ZSCAN9,SREBF2,HNF4G,TFEB,ZNF274,CREBL2,JUND,ZBTB20,ETS2,PRDM6,RARB,ZNF174,MEIS3,HBP1,NR4A1,ZNF316,NRF1,ZNF687,REST,ZBTB7C,PBX1,NFIL3,ZNF644,KLF1,ZNF624,MLX,ETV4,SOX5,ZNF707,ZNF266,ZNF43,ZNF155,THRA,TFAP2C,HMBOX1,SCRT1,CTCFL,ZC3H8,NEUROD4,NFYC,ZNF30,ESR2,HSF5,HIC1,ZNF34,ZNF491,ZNF404,ZNF354C,SOX9,PRDM10,E2F4,CREM,ZFP3,VDR,ZNF14,HLF,ZXDB,ZNF704,ZSCAN2,E2F2,NR3C1,IKZF2,KAT7,REPIN1,ZNF680,ZNF20,ZNF157,IRF9,BATF,ZNF740,MAZ,ZNF850,NFIA,E2F7,ZNF19,KLF5,OVOL3,ZNF26,BHLHE40,NFE4,ZNF10,ZNF584,ZNF639,MXI1,ZNF365,ZNF514,MXD4,INSM1,ELK1,ZNF423,MAFF,ZNF207,ZIK1,SKIL,KLF8,HHEX,ZNF519,ZNF280C,ATF4,ZFP37,ZNF610,ZNF324,ZFHX3,ZNF747,TEAD4,ZBTB8A,ZKSCAN5,TBP,ZNF318,ZIC2,ZNF629,ZNF24,DNMT1,ZNF16,ZNF48,HINFP,TCF7,MAFK,PPARG,SNAI3,ZSCAN29,ZNF391,ELF4,ETV6,MAFG,ZNF777,ZNF558,ZNF766,ZNF524,OSR1,HMGN3,ZFP64,CBX2,ZNF300,ZSCAN16,ZNF394,ZFP69,ZNF280D,ZSCAN4,TEAD1,IRF5,ZNF600,TGIF1,SMAD4,HOXC5,ZBTB40,SIX4,ERG,RFX7,ZNF79,KLF16,CUX1,IRF7,EGR4,DPF3,ZSCAN18,THRB,SIX5,ZNF670,TAL1,SP5,SPIC,MYNN,YBX1,ZNF248,ZNF697,MITF,MEF2D,CHAMP1,ZNF384,ZFX,ZNF239,ZNF8,TFDP2,ZNF2,MEF2C,ZNF837,ZNF66,TSC22D1,ZNF350,BRF2,ZNF175,NFE2L2,ZBTB17,ZNF347,ZNF488,KLF7,ZNF507,KMT2B,RBAK,ZNF548,ZNF664,KLF3,ZNF57,CTCF,ZZZ3,ZNF776,ZNF407,E2F5,ZBED9,LCORL,ZNF70,TBX1,USF1,ZGPAT,MIXL1,ZNF45,PRDM1,ZNF114,ZNF84,ZNF195,MTF2,REL,SRF,ZNF555,ZNF148,ZNF398,ZNF579,ZNF654,E2F6,KLF6,MBD4,HMG20B,RFX5,ZNF512,ZNF140,MAX,MYB,ATF7,ZKSCAN8,ZNF426,BCL6,TCF7L1,ZNF76,ZNF69,ZNF138,CDC5L,CEBPG,ZNF335,RXRB,SP4,KLF17,NFXL1,TCF21,ZNF544,ZNF197,ZNF416,ZSCAN26,CEBPD,ESRRB,ZHX2,TFAP4,KLF9,HNF4A,RUNX2,ZBTB48,MBD1,NR2F6,ZNF589,PRDM4,ZNF7,T,ZNF181,DEAF1,TEAD2,IRF4,ZBTB5,ELK4,ZNF169,ZNF22,ZBTB26,KLF4,SOX1,ZFP1,ZNF529,SP7,ZBTB49,SOX6,NR2C2,ELF2,ZNF560,NANOG,STAT1,ZNF785,NFIC,ZNF366,DRAP1,MYC

tissue_types: heart

pileup: 1.0

log_p: 100.0

fold_enrichment: 1.0

log_q: 100.0

dist_tss_upstream: 1000

dist_tss_downstream: 100

peak_count: 1

include_motif_sites: <input checked id="include_motif_sites" name="include_motif_sites" type="checkbox" value="y">

motif_discovery: <input id="motif_discovery" name="motif_discovery" type="checkbox" value="y">

email: send.results.here@peaks.com