PLEASE READ THROUGH THIS DOCUMENT BEFORE USING THE PROVIDED data

-Thank you for using ChIP-IO-

Current Reference Genome: GRCh38
Current Annotation: gencode.v29

------------ Output Description ------------

*** .tgtable file ***

Your output folder contains a .tgtable file. This is actually a tab-seperated value(tsv) file. It contains tabular data 
with the metadata:

Rows: Gene + Gene Regions
Columns: Transcription Factors

Table entries correspond to the number of ChIP-Seq peaks for a given transcription factor mapping to regulatory regions of
a given gene. Currently these peaks come only from raw ChIP-Seq peak data, but future versions will include motif/epigenetic
prior binding site prediction to reduce false positive rates where applicable.

*** .bintgtable file ***

Same as above, except entries are binarized as 0 or 1 based on the "peak count" threshold.

*** .pkl file ***

Python readable binarytable object. Holds the same information as the above .tsv files but can be read into python as a nested
dictionary object. Once read in, entries can be pulled as table[gene][tf]

------------ Important Notes! ------------

- In general, "0" table entries are not intended to provide confidence for lack of TF-gene association. ChIP-Seq studies still 
cover only a subset of transcription factors, and there may always be variation across cell states which is not well
captured. Instead, focus on interpreting non-zero entries as providing experimental confidence of association over neutral.

- If multi-tissue selection was done, the final output table will contain a union of data across tissue types specified in the
ChIP-IO query. If you are interested in tf-gene association for a single tissue type, submit a new query inputting only that 
tissue. 

------------ Current Submission ------------

time stamp: 2018-12-19_17:57:27.765901

promoter: True

enhancer: True

transcription_factors: REL,ZBTB17,MEF2D,ZBED9,HMGN3,ZNF45,ZSCAN2,STAT5A,ZNF610,MAFF,SREBF2,ZNF680,ZNF654,MEIS3,ZNF195,DRAP1,ZNF248,KDM5B,TCF3,ZNF548,CDC5L,ZNF354C,ZNF529,RXRB,ZNF398,ZNF24,ZNF76,MBD1,RFX5,KLF7,ZNF544,SP7,SKIL,JUND,MTF2,TAL1,CBX2,ZNF740,SCRT1,TFDP2,HNF4A,SP4,ZNF697,ZNF605,ZNF488,THRB,NKX2-8,ZNF391,HOXC5,BHLHE40,ZNF66,ELK4,ZFP69,INSM1,SOX5,ZFHX3,ESR2,KAT7,CEBPZ,SMAD5,ZNF347,ZNF629,HBP1,ZNF274,TBX1,ZNF365,NR4A1,REPIN1,RBAK,MLX,ZFX,E2F6,MEF2C,KLF1,ZNF20,NFXL1,ZNF423,MXI1,ZNF394,ZNF366,TCF7L1,ZNF43,MBD4,NFE4,ZNF318,NFATC4,KLF6,ETS2,KLF9,ADNP,DPF3,ZSCAN4,TCF21,ZNF639,ZNF579,DNMT1,ZNF335,MYB,ATF4,ETV6,ZNF530,TFEB,ZNF239,ZNF514,ZNF84,THRA,IRF4,ZNF30,ZNF547,ZNF645,ZNF174,ZNF7,KLF5,SIX4,ZNF589,MXD1,TFAP2C,PPARG,NR2C2,ELK1,ZIK1,BCL11B,ZNF57,BCL6,ZNF26,ZFP1,E2F4,RUNX2,STAT1,PRDM4,ZNF426,SIX5,ZZZ3,PRDM1,TGIF1,ZNF384,CHAMP1,ZBTB49,ZNF146,ZNF524,ZNF704,REST,OSR1,TEAD4,CTCF,ZNF558,ZKSCAN8,ZNF407,ERG,SPIC,HMG20B,ZNF350,ZFP64,ZNF181,ZNF580,BACH1,ZBTB7C,ZNF197,ZBTB8A,ZNF14,ZNF175,MITF,ETV4,ZNF18,NCOA2,ZNF79,ZSCAN29,ZNF34,ZNF785,ZNF8,IRF5,SRF,HNF4G,ZFP3,SMAD4,ZNF584,E2F2,NFIA,ZNF114,ZBTB26,VDR,NFYC,BATF,SNAI3,ZNF404,SALL1,ZNF300,ZNF837,ZNF747,EGR4,MAZ,ZBTB40,HSF5,ZNF22,ATF7,ZBTB10,TEAD2,IRF7,NANOG,TFAP4,ZNF776,ZNF512,KLF16,JUN,TBP,ZNF169,TSHZ2,ZSCAN26,ZNF10,NFIL3,HIC1,SOX6,E2F7,ZNF280D,ZNF777,IRF9,ELF4,KLF3,ZNF19,ZNF624,ZNF644,ZBTB20,RFX7,ZSCAN16,ZNF207,ZNF707,CEBPD,MAFK,ZNF687,ZNF70,SOX1,HHEX,PRDM10,TCF7,HLF,E2F5,NFE2L2,ZHX2,DEAF1,BRF2,ZNF184,ZNF416,ZGPAT,NFIC,CREBL2,ZNF2,ZNF324,ZNF560,ZIC2,ZNF658,IKZF2,RARB,GATA6,HMBOX1,SOX9,MXD4,ZSCAN9,CREM,HES5,ESRRB,CEBPG,ZC3H8,ZNF600,THAP4,KLF8,TSC22D1,ZNF491,MAX,ZNF850,SP5,MAFG,MYNN,ZNF155,ZNF555,ZNF316,KLF4,TEAD1,ZNF280C,YBX1,ZFP37,PRDM6,ZNF507,T,ZNF48,OVOL3,ELF2,ZSCAN5C,HOMEZ,NEUROD4,ZNF578,ZNF140,ZNF766,ZNF148,ZNF138,ZBTB5,ZSCAN18,MYC,ZNF157,PBX1,NR2F6,NRF1,ZXDB,HINFP,EBF1,ZBTB48,KLF17,CUX1,ZNF664,ZKSCAN5,ZNF519,ZNF69,ZNF217,ZNF16,MIXL1,USF1,CTCFL,NR3C1,KMT2B,ZNF266,ZNF670,LCORL

tissue_types: blood

pileup: 1.0

log_p: 3.0

fold_enrichment: 1.0

log_q: 3.0

dist_tss_upstream: 1000

dist_tss_downstream: 100

peak_count: 1

include_motif_sites: <input checked id="include_motif_sites" name="include_motif_sites" type="checkbox" value="y">

motif_discovery: <input id="motif_discovery" name="motif_discovery" type="checkbox" value="y">

email: send.results.here@peaks.com