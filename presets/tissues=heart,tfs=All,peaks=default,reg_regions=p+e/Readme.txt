PLEASE READ THROUGH THIS DOCUMENT BEFORE USING THE PROVIDED data

-Thank you for using ChIP-IO-

Current Reference Genome: GRCh38
Current Annotation: gencode.v29

------------ Output Description ------------

*** .tgtable file ***

Your output folder contains a .tgtable file. This is actually a tab-seperated value(tsv) file. It contains tabular data 
with the metadata:

Rows: Gene + Gene Regions
Columns: Transcription Factors

Table entries correspond to the number of ChIP-Seq peaks for a given transcription factor mapping to regulatory regions of
a given gene. Currently these peaks come only from raw ChIP-Seq peak data, but future versions will include motif/epigenetic
prior binding site prediction to reduce false positive rates where applicable.

------------ Important Notes! ------------

- In general, "0" table entries are not intended to provide confidence for lack of TF-gene association. ChIP-Seq studies still 
cover only a subset of transcription factors, and there may always be variation across cell states which is not well
captured. Instead, focus on interpreting non-zero entries as providing experimental confidence of association over neutral.

- If multi-tissue selection was done, the final output table will contain a union of data across tissue types specified in the
ChIP-IO query. If you are interested in tf-gene association for a single tissue type, submit a new query inputting only that 
tissue. 

------------ Current Submission ------------

time stamp: 2018-12-14_00:40:39.691074

promoter: True

enhancer: True

transcription_factors: ZSCAN2,TSC22D1,ZNF76,ZNF45,REPIN1,ELK1,NRF1,CTCFL,ZNF181,PRDM1,ZXDB,ZNF407,BHLHE40,REST,BCL6,ZNF155,HMBOX1,CTCF,ZSCAN26,ZNF664,ZNF704,CEBPZ,ZSCAN5C,ZNF687,ZNF644,STAT5A,MITF,ZSCAN4,ZNF280D,HSF5,ZFP69,SP7,NR3C1,KLF9,MXD4,KLF6,NEUROD4,CDC5L,MAFK,ZNF624,HMGN3,HIC1,TFAP4,SNAI3,IRF7,HNF4A,JUN,ZNF2,BACH1,ZNF580,EGR4,E2F4,TCF7L1,DEAF1,ZBTB17,E2F7,ZNF69,HNF4G,ZNF507,ZNF354C,ZNF350,ZNF850,E2F6,SOX1,ZNF766,THAP4,ZNF426,CREBL2,NANOG,TFDP2,ZNF138,SALL1,ZNF837,NFIA,ZNF175,ETS2,MYNN,ZNF30,TBX1,MIXL1,ZNF391,ZNF197,ZNF266,SP5,ESR2,ZNF578,ZBTB40,NFE4,ZFX,ZNF785,TGIF1,ZNF514,ZFP3,TFEB,LCORL,TEAD2,ZNF605,ZFP37,ZNF670,ZNF324,KLF5,ZFP1,TCF3,MAFF,ZKSCAN8,ZNF776,ZNF335,SIX4,MAX,MXD1,RFX5,HOXC5,ZC3H8,BATF,ZNF707,ZNF747,NFE2L2,TSHZ2,E2F2,KLF3,NFIC,ZNF558,KLF17,HOMEZ,ZNF300,ZNF184,CREM,USF1,HHEX,ZNF48,ZNF610,ZNF524,SOX6,MAZ,SOX5,ZNF548,ZNF530,ZNF589,ZNF318,ERG,RXRB,RFX7,BRF2,ZNF79,MEIS3,ZNF217,ZNF20,ESRRB,NFATC4,ZNF248,SMAD4,PRDM4,MBD1,EBF1,PRDM10,ATF7,ZNF584,ZBTB5,ZNF169,ZNF555,ZSCAN9,ZIK1,ZNF347,MBD4,SIX5,ZNF43,ZFP64,MYC,NFXL1,TAL1,NCOA2,ZIC2,HINFP,ZNF423,ZSCAN16,IKZF2,VDR,ZNF404,ELF2,ZSCAN18,ZNF70,NR2F6,MEF2C,YBX1,ZBTB7C,ZNF146,OVOL3,ZNF16,KLF7,OSR1,CBX2,TCF21,ZNF547,NFIL3,ZNF316,BCL11B,MEF2D,KLF8,NFYC,TFAP2C,JUND,PRDM6,ZNF24,ZNF207,ELF4,ETV6,TBP,KLF16,ZNF114,IRF5,ZNF239,KDM5B,ZNF22,PBX1,ZNF280C,RBAK,ZNF14,ZBTB8A,ZFHX3,ZNF157,ZNF416,HMG20B,ZBTB48,DPF3,TEAD4,ZNF26,DRAP1,ZNF639,STAT1,NKX2-8,RUNX2,ZNF658,IRF9,ZNF66,ZNF560,SP4,ZNF398,ZNF8,THRA,ZNF34,ZNF84,ZNF519,ZNF57,INSM1,ZNF384,CEBPD,RARB,NR4A1,TCF7,KLF4,T,HBP1,ZNF174,DNMT1,ZNF18,ZNF512,KMT2B,ZNF140,CEBPG,SMAD5,KLF1,HES5,ZNF777,MTF2,PPARG,ZKSCAN5,ZNF19,ZNF645,ZSCAN29,ETV4,ZGPAT,ZNF148,NR2C2,ZNF579,IRF4,ZNF7,CUX1,ZBTB20,MYB,ZNF488,ZNF491,ZNF544,SPIC,ZBED9,ZNF366,ZNF680,E2F5,SREBF2,MAFG,KAT7,ZNF697,SRF,HLF,TEAD1,THRB,ZBTB26,ZBTB10,ZNF394,ZNF654,ZNF600,GATA6,SOX9,REL,ZNF195,ELK4,MLX,SCRT1,ZNF10,ZNF365,ZNF740,ZNF274,ATF4,MXI1,ZZZ3,ZBTB49,ZNF629,ZNF529,ADNP,ZHX2,SKIL,CHAMP1

tissue_types: heart

pileup: 1.0

log_p: 3.0

fold_enrichment: 1.0

log_q: 3.0

dist_tss_upstream: 1000

dist_tss_downstream: 100

peak_count: 1

include_motif_sites: <input checked id="include_motif_sites" name="include_motif_sites" type="checkbox" value="y">

motif_discovery: <input id="motif_discovery" name="motif_discovery" type="checkbox" value="y">

email: send.results.here@peaks.com