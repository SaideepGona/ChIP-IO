PLEASE READ THROUGH THIS DOCUMENT BEFORE USING THE PROVIDED data

-Thank you for using ChIP-IO-

Current Reference Genome: GRCh38
Current Annotation: gencode.v29

------------ Output Description ------------

*** .tgtable file ***

Your output folder contains a .tgtable file. This is actually a tab-seperated value(tsv) file. It contains tabular data 
with the metadata:

Rows: Gene + Gene Regions
Columns: Transcription Factors

Table entries correspond to the number of ChIP-Seq peaks for a given transcription factor mapping to regulatory regions of
a given gene. Currently these peaks come only from raw ChIP-Seq peak data, but future versions will include motif/epigenetic
prior binding site prediction to reduce false positive rates where applicable.

------------ Important Notes! ------------

- In general, "0" table entries are not intended to provide confidence for lack of TF-gene association. ChIP-Seq studies still 
cover only a subset of transcription factors, and there may always be variation across cell states which is not well
captured. Instead, focus on interpreting non-zero entries as providing experimental confidence of association over neutral.

- If multi-tissue selection was done, the final output table will contain a union of data across tissue types specified in the
ChIP-IO query. If you are interested in tf-gene association for a single tissue type, submit a new query inputting only that 
tissue. 

------------ Current Submission ------------

time stamp: 2018-12-13_22:59:27.203088

promoter: True

enhancer: True

transcription_factors: ZNF687,TSC22D1,SP5,KLF9,ZBTB20,ZNF740,MXI1,EBF1,ZNF398,KDM5B,SRF,ZNF138,MAFF,MTF2,ZNF318,SOX1,KAT7,ZNF197,ZNF70,MXD1,ZKSCAN8,MXD4,ZNF680,ZNF507,ZNF57,ZNF670,ZNF391,ZFHX3,ELF4,E2F4,ZFP37,MYNN,USF1,ZNF530,IRF4,HOXC5,KLF5,ZNF48,ZNF140,ZSCAN29,ZNF578,BHLHE40,MEF2C,ZFP64,TBX1,CEBPZ,ZNF488,ZNF610,SPIC,ZNF335,ZNF512,KMT2B,VDR,ZNF654,RFX5,ZNF266,ZNF580,ZNF43,ZNF548,RUNX2,ZNF239,BCL6,ZFP1,ZNF66,NR2F6,ZNF384,IRF9,ZIC2,ZNF519,ZNF300,E2F6,ZSCAN18,ZNF707,YBX1,SREBF2,ZNF837,DRAP1,MBD4,TFEB,THAP4,ZNF16,MAFK,ZNF624,ZNF547,ZKSCAN5,ZBTB40,ZNF560,ZNF184,ELK1,ZNF404,TCF21,ZNF195,HNF4A,ZGPAT,ZNF69,ZNF207,MBD1,TEAD2,SP7,KLF8,ZSCAN5C,ATF4,ZNF605,HBP1,ZSCAN9,ZNF24,CHAMP1,BCL11B,PPARG,CTCF,CTCFL,NFE2L2,ZFP69,ZNF629,ZNF84,NFATC4,ZFX,RBAK,KLF6,IKZF2,KLF4,ZSCAN26,NR3C1,BRF2,GATA6,CREM,TSHZ2,ZNF146,CREBL2,ZBTB10,ZNF8,STAT1,HMGN3,ETV4,ZNF704,ETV6,T,TFAP2C,DEAF1,BACH1,TEAD1,ZNF76,ZNF19,ZNF350,HMBOX1,ZNF584,MEF2D,ZBTB26,IRF5,ZNF639,ZSCAN16,ZNF280D,RARB,ZNF20,ZNF10,ZNF776,REPIN1,RFX7,ZNF491,ZNF324,NKX2-8,INSM1,ZNF354C,ZNF785,ZNF645,MYB,TGIF1,ZNF555,ZNF217,ZBTB8A,ZNF544,ZNF2,KLF7,ZNF174,ZNF514,ZNF524,NFIA,HSF5,ZNF79,ZNF366,SNAI3,ZSCAN4,ZNF316,ZNF766,IRF7,THRA,PRDM6,MLX,ZNF45,SP4,TFAP4,PRDM1,TCF7,ZNF22,NANOG,PBX1,KLF17,TCF3,ZNF26,ZC3H8,REL,E2F2,ZNF558,ZBTB7C,MIXL1,TFDP2,TBP,THRB,ZIK1,ZNF34,ZNF280C,ZNF644,LCORL,ZBTB48,ZNF777,SMAD4,HOMEZ,ZNF407,REST,NCOA2,SOX6,OSR1,ZNF529,ZNF155,ZNF416,ZNF248,ZBTB5,SCRT1,NFXL1,ZNF579,ZNF664,ZNF114,MAX,ZHX2,ZSCAN2,HNF4G,JUN,ATF7,SKIL,EGR4,PRDM4,E2F7,ZBTB49,HLF,HINFP,HIC1,NFIL3,TEAD4,ZNF14,SOX9,DNMT1,SALL1,NRF1,ZXDB,CDC5L,CEBPG,NFE4,NFIC,ZNF394,ZNF18,SIX5,ZNF148,CBX2,KLF3,SMAD5,ZNF7,ESR2,ZNF747,DPF3,CUX1,OVOL3,BATF,PRDM10,MITF,NEUROD4,ZNF365,HHEX,ZNF423,ZFP3,KLF1,ZZZ3,ELF2,STAT5A,ZNF658,TAL1,MAFG,ZNF589,CEBPD,NFYC,RXRB,SOX5,NR4A1,ZNF850,ZNF30,ZNF697,ZNF426,E2F5,ERG,ZNF175,SIX4,ZNF600,ZNF181,HES5,TCF7L1,MAZ,JUND,ZBTB17,ZNF347,ZBED9,MEIS3,ZNF157,KLF16,ELK4,ADNP,ZNF274,ZNF169,MYC,ETS2,NR2C2,ESRRB,HMG20B

tissue_types: breast_carcinoma_cell_line,spleen,lung_carcinoma_cells,neonatal_human_foreskin_fibroblasts_(primary_culture_cells),Breast_cancer_derived_cell_line,intestine,bone_element,lymphoblastoid,liver,bodily_fluid,bronchus,adrenal_gland,EBV_positive_B_lymphocyte_line,Th1,NA,ovary,myelogenous_leukaemia,KSHV_positive_B_cell_lymphoma,Human_keratinocytes,Jurkat,_clone_E6-1_T_lymphocyte,mammary_gland,large_intestine,connective_tissue,testis,EBV_positive_B-cells,kidney,skin_of_body,CD133+_expanded_UCB,lung,uterus,vasculature,stomach,HSPC,gonad,peripheral_blood_mononuclear_cells_(PBMCs),musculature_of_body,Epstein-Barr_Virus_transformed_lymphoblastoid,limb,lymphoid_tissue,extraembryonic_component,human_hepatic_stellate_cells,blood,Epithelial_cells_immortalized_with_hTERT,pancreas,colorectal_carcinoma,blood_vessel,Leukemic_T-cell,prostate_gland,spinal_cord,T-acute_lymphoblastic_leukemia_(T-ALL)_cell_line,embryo,lymph_node,heart,artery,eye,brain,esophagus,thyroid_gland,epithelium,placenta,vagina,penis,corneal_epithelium_cell_(CEC)_line,nerve,CD34+_derived_erythroblasts,None,vein,adipose_tissue,breast

pileup: 1.0

log_p: 3.0

fold_enrichment: 1.0

log_q: 3.0

dist_tss_upstream: 1000

dist_tss_downstream: 100

peak_count: 1

include_motif_sites: <input checked id="include_motif_sites" name="include_motif_sites" type="checkbox" value="y">

motif_discovery: <input id="motif_discovery" name="motif_discovery" type="checkbox" value="y">

email: send.results.here@peaks.com