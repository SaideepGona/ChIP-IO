PLEASE READ THROUGH THIS DOCUMENT BEFORE USING THE PROVIDED data

-Thank you for using ChIP-IO-

Current Reference Genome: GRCh38
Current Annotation: gencode.v29

------------ Output Description ------------

*** .tgtable file ***

Your output folder contains a .tgtable file. This is actually a tab-seperated value(tsv) file. It contains tabular data 
with the metadata:

Rows: Gene + Gene Regions
Columns: Transcription Factors

Table entries correspond to the number of ChIP-Seq peaks for a given transcription factor mapping to regulatory regions of
a given gene. Currently these peaks come only from raw ChIP-Seq peak data, but future versions will include motif/epigenetic
prior binding site prediction to reduce false positive rates where applicable.

*** .bintgtable file ***

Same as above, except entries are binarized as 0 or 1 based on the "peak count" threshold.

*** .pkl file ***

Python readable binarytable object. Holds the same information as the above .tsv files but can be read into python as a nested
dictionary object. Once read in, entries can be pulled as table[gene][tf]

------------ Important Notes! ------------

- In general, "0" table entries are not intended to provide confidence for lack of TF-gene association. ChIP-Seq studies still 
cover only a subset of transcription factors, and there may always be variation across cell states which is not well
captured. Instead, focus on interpreting non-zero entries as providing experimental confidence of association over neutral.

- If multi-tissue selection was done, the final output table will contain a union of data across tissue types specified in the
ChIP-IO query. If you are interested in tf-gene association for a single tissue type, submit a new query inputting only that 
tissue. 

------------ Current Submission ------------

time stamp: 2018-12-19_03:31:45.015969

promoter: True

enhancer: True

transcription_factors: ZBTB8A,DRAP1,HIC1,NFXL1,JUND,ZXDB,ETV4,NR2C2,NFYC,HOXC5,ZSCAN18,NFATC4,NEUROD4,ZNF14,TGIF1,ZIC2,SOX5,NCOA2,ZNF69,HSF5,ZSCAN29,ZNF169,IRF5,BATF,SALL1,ESRRB,KLF8,ZNF217,ZNF114,HLF,ZNF629,ZNF335,MBD4,ZNF398,NFE4,MAX,ZNF175,TCF21,ZNF644,ETV6,ZNF239,PRDM1,ZNF266,ZNF519,ZNF407,CDC5L,ZNF365,ZFP64,ZNF354C,ZSCAN26,MYB,ZNF43,HMG20B,SREBF2,ZFP69,MIXL1,ZNF280C,DEAF1,ZNF366,IKZF2,ZFX,ZNF850,LCORL,ZNF524,MXD4,SRF,OSR1,ZNF426,CREM,HBP1,ZBTB49,ZNF529,THAP4,HINFP,BCL11B,ZNF488,ZSCAN4,SP5,THRA,TEAD2,ZBTB26,RBAK,TFAP4,TFAP2C,ZNF680,RXRB,IRF4,NKX2-8,RFX5,ZNF207,NR2F6,MLX,STAT5A,ZNF670,ZNF558,ZNF610,ZNF48,ZNF512,ZNF514,MTF2,ZNF707,REPIN1,MBD1,ZNF687,ZNF350,TEAD4,ZNF181,ESR2,PPARG,ZNF10,ERG,JUN,ZNF184,ZGPAT,ZNF316,ZNF76,ZNF600,KLF7,ZNF280D,SIX4,SOX1,ZNF70,ZNF766,TSHZ2,CEBPG,MEF2D,TEAD1,ZNF138,ZNF157,KLF17,ZNF19,ELF2,ZNF639,SOX9,TCF7L1,E2F2,E2F6,MEIS3,MITF,NFIC,KLF5,CTCFL,HES5,ZNF174,CREBL2,ZNF57,ZNF547,TCF7,ZNF645,ZNF26,ZBTB17,ZFP37,ZNF384,E2F4,ZSCAN2,ATF4,HMBOX1,ZNF66,VDR,ZBTB48,KLF9,ZBTB20,ZNF654,ATF7,ZNF140,BACH1,ZNF777,SPIC,ZBTB5,NRF1,ZKSCAN8,MAFF,ZNF404,EBF1,NR3C1,ZNF530,TFDP2,ZNF584,ZNF548,ZNF79,NFIL3,USF1,ZNF624,ZNF394,NFIA,SMAD5,PRDM6,ZNF491,ZBTB10,CHAMP1,RUNX2,NANOG,HOMEZ,ZNF197,SP4,OVOL3,ADNP,PRDM4,MEF2C,SOX6,ZNF274,ELF4,SKIL,ZNF195,SMAD4,KDM5B,MYNN,ZFP1,ZNF84,ZFHX3,NR4A1,REL,ZHX2,TCF3,ZNF740,ZNF704,GATA6,ZNF589,TBP,ZIK1,ZBTB40,ZNF2,SCRT1,KLF6,THRB,ZNF776,HHEX,ETS2,EGR4,ZNF658,YBX1,BCL6,BHLHE40,ZNF7,CUX1,ZNF16,ZSCAN16,ZNF347,ZNF560,ZNF605,ZNF324,ZNF146,ZNF664,KLF4,ZNF30,PBX1,ZSCAN9,MXI1,TSC22D1,HNF4A,NFE2L2,TFEB,DNMT1,ZNF697,ZNF785,ZNF34,RFX7,ZNF423,ZBED9,ZNF837,ZNF318,ZNF8,CEBPZ,IRF9,ZNF580,T,MAFK,ZFP3,SNAI3,ZNF578,ZSCAN5C,ZNF300,ZNF391,ZZZ3,KAT7,ELK1,ZNF22,REST,KLF1,STAT1,ZNF45,ZNF20,PRDM10,ZBTB7C,CEBPD,INSM1,ZNF155,KLF3,ZNF18,CTCF,E2F5,ZNF148,CBX2,MYC,ZNF747,KMT2B,ZNF544,KLF16,HMGN3,ZC3H8,RARB,ZNF579,SIX5,MXD1,ZNF416,MAZ,TBX1,E2F7,ELK4,ZKSCAN5,ZNF24,HNF4G,DPF3,ZNF507,SP7,BRF2,ZNF555,TAL1,ZNF248,IRF7,MAFG

tissue_types: brain

pileup: 1.0

log_p: 100.0

fold_enrichment: 1.0

log_q: 100.0

dist_tss_upstream: 1000

dist_tss_downstream: 100

peak_count: 1

include_motif_sites: <input checked id="include_motif_sites" name="include_motif_sites" type="checkbox" value="y">

motif_discovery: <input id="motif_discovery" name="motif_discovery" type="checkbox" value="y">

email: send.results.here@peaks.com